# IPTV-MD
## IPTV Panel:



## Installation options:
### Option 1: Fresh installation
1. `cd ~/ && wget https://github.com/xtronica/Painel-IPTV-MD/master/fresh_install.sh`
2. `chmod 755 fresh_install.sh`
3. `./fresh_install.sh`
