<embed type="application/x-vlc-plugin" name="player" autoplay="yes" loop="no" width="340" height="300" target="{{ $streamurl }}">
            